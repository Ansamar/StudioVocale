def genera_audio(testo, speaker, formato, nome_file, cartella, salva_file, velocita, tono, presenza):
    if not testo.strip():
        return None, "❌ Testo vuoto."
    if not speaker:
        return None, "❌ Voce non selezionata."

    speaker_path = os.path.join(SPEAKER_DIR, f"{speaker}.wav")
    if not os.path.exists(speaker_path):
        return None, f"❌ Speaker non trovato: {speaker_path}"

    temp_wav = "temp_audio.wav"
    comando = [
        "tts",
        "--model_name", "tts_models/multilingual/multi-dataset/xtts_v2",
        "--text", testo,
        "--speaker_wav", speaker_path,
        "--language_idx", "it",
        "--out_path", temp_wav
    ]

    try:
        result = subprocess.run(comando, capture_output=True, text=True)
        if result.returncode != 0:
            return None, f"❌ Errore TTS:\n{result.stderr}"
    except Exception as e:
        return None, f"❌ Errore esecuzione TTS: {e}"

    if not os.path.exists(temp_wav):
        return None, "❌ Audio non generato."

    audio = AudioSegment.from_wav(temp_wav)

    # 🎚️ Velocità
    if velocita != 1.0:
        audio = effects.speedup(audio, playback_speed=velocita)

    # 🎼 Tono (Pitch shift)
    if tono != 0:
        factor = 2 ** (tono / 12.0)
        new_frame_rate = int(audio.frame_rate * factor)
        audio = audio._spawn(audio.raw_data, overrides={"frame_rate": new_frame_rate})
        audio = audio.set_frame_rate(44100)

    # 🌟 Presenza (Equalizzazione)
    def equalizza(audio, livello):
        if livello == "Intima":
            return audio.low_pass_filter(3000).high_pass_filter(300)
        elif livello == "Morbida":
            return audio.low_pass_filter(4000)
        elif livello == "Nitida":
            return audio.high_pass_filter(2000)
        elif livello == "Proclamata":
            return audio.high_pass_filter(2500).apply_gain(+3)
        elif livello == "Enfatizzata":
            return audio.high_pass_filter(3000).apply_gain(+6)
        else:
            return audio  # Neutra

    audio = equalizza(audio, presenza)

    # 💾 Salvataggio
    if not salva_file:
        audio.export("preview.wav", format="wav")
        return "preview.wav", "🧪 Audio generato (non salvato)"

    os.makedirs(cartella, exist_ok=True)
    wav_path = os.path.join(cartella, f"{nome_file}.wav")
    audio.export(wav_path, format="wav")

    if formato == "mp3":
        mp3_path = os.path.join(cartella, f"{nome_file}.mp3")
        try:
            audio.export(mp3_path, format="mp3")
            os.remove(wav_path)
            return mp3_path, "✔️ MP3 salvato"
        except Exception as e:
            return wav_path, f"⚠️ Conversione MP3 fallita: {e}"

    return wav_path, "✔️ WAV salvato"
